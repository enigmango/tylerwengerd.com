Thank you for purchasing "Negative Space"

To activate "Negative Space," upload the entire "Negative Space" folder to your Ghost theme folder. Go to settings in the Ghost admin 
scroll down the the theme dropbox, choose "Negative Space" and save.

To add your logo to negative space, go to settings in the Ghost Admin, choose "Blog Logo," upload your logo and save.
Recommended logo size is: 287px by 28px

To create a static page in Ghost, simply click the gear icon on either the content page or the edit page and check the static page box.

You can add your own links to static pages in /partials/top-nav.hbs

Any questions, please contact us at:
http://madeforghost.com

Thank you again!